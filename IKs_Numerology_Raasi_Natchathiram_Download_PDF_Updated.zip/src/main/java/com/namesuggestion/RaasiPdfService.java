package com.namesuggestion;

import org.apache.pdfbox.pdmodel.PDDocument;
import org.apache.pdfbox.pdmodel.PDPage;
import org.apache.pdfbox.pdmodel.PDPageContentStream;
import org.apache.pdfbox.pdmodel.common.PDRectangle;
import org.apache.pdfbox.pdmodel.font.PDFont;
import org.apache.pdfbox.pdmodel.font.PDType1Font;
import org.apache.pdfbox.pdmodel.font.Standard14Fonts;
import org.apache.pdfbox.pdmodel.graphics.image.PDImageXObject;
import java.io.InputStream;
import org.springframework.stereotype.Service;

import java.awt.Color;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.Locale;

/** A single-page, printable download of the Raasi/Natchathiram screen result.
 * Uses the same validated BirthResult returned by /raasi; no Sarvam call.
 */
@Service
public class RaasiPdfService {
    private static final PDFont NORMAL = new PDType1Font(Standard14Fonts.FontName.HELVETICA);
    private static final PDFont BOLD = new PDType1Font(Standard14Fonts.FontName.HELVETICA_BOLD);
    private static final float W = PDRectangle.A4.getWidth();
    private static final float H = PDRectangle.A4.getHeight();
    private static final Color NAVY = new Color(24, 40, 71);
    private static final Color TEXT = new Color(28, 42, 65);
    private static final Color MUTED = new Color(90, 103, 121);
    private static final Color PALE = new Color(245, 248, 252);
    private static final Color LINE = new Color(220, 226, 233);
    private static final Color GREEN = new Color(226, 244, 232);
    private static final Color GREEN_DARK = new Color(17, 102, 61);
    private static final DateTimeFormatter DATE = DateTimeFormatter.ofPattern("dd/MM/uuuu", Locale.ENGLISH);
    private static final DateTimeFormatter TIME = DateTimeFormatter.ofPattern("hh:mm a", Locale.ENGLISH);

    public byte[] render(RaasiCalculatorService.BirthResult r) throws IOException {
        try (PDDocument document = new PDDocument(); ByteArrayOutputStream bytes = new ByteArrayOutputStream()) {
            PDPage page = new PDPage(PDRectangle.A4);
            document.addPage(page);
            try (PDPageContentStream out = new PDPageContentStream(document, page)) {
                // Brand and title
                rect(out, 37, 759, W - 74, 55, NAVY, NAVY);
                label(out, BOLD, 18, 52, 787, Color.WHITE, "IK's Numerology");
                label(out, NORMAL, 10, 52, 769, Color.WHITE, "Raasi / Natchathiram / Pada - Birth Report");

                heading(out, 741, "BIRTH DETAILS");
                rect(out, 37, 657, W - 74, 73, PALE, LINE);
                field(out, 52, 705, "Date of Birth", r.dateOfBirth().format(DATE));
                field(out, 302, 705, "Time of Birth", r.timeOfBirth().format(TIME) + " IST");
                field(out, 52, 675, "Place of Birth", r.placeOfBirth());
                field(out, 302, 675, "Time Zone", "Asia/Kolkata (UTC+05:30)");

                heading(out, 642, "RAASI, NATCHATHIRAM & PADA");
                stat(out, 37, 549, 168, 78, "RAASI", r.raasi(), "");
                drawTamil(out, document, "raasi-" + slug(r.raasi()) + ".png", 50, 556, 12);
                stat(out, 213, 549, 168, 78, "NATCHATHIRAM", r.natchathiram(), "");
                drawTamil(out, document, "nakshatra-" + slug(r.natchathiram()) + ".png", 226, 556, 12);
                stat(out, 389, 549, 168, 78, "PADA", String.valueOf(r.pada()), "Quarter of star");

                heading(out, 531, "BIRTH NUMBERS");
                stat(out, 37, 449, 168, 68, "VITHI EN", Integer.toString(r.vithiEn()), "Full date of birth");
                stat(out, 213, 449, 168, 68, "MATHI EN", Integer.toString(r.mathiEn()), "Day of month");
                stat(out, 389, 449, 168, 68, "FRIENDLY EN", r.friendlyEn().isBlank() ? "-" : r.friendlyEn(), "For Vithi En " + r.vithiEn());
                label(out, NORMAL, 8.1f, 42, 436, TEXT, "Vithi calculation: " + r.vithiCalculation());
                label(out, NORMAL, 8.1f, 42, 423, TEXT, "Mathi calculation: " + r.mathiCalculation());

                heading(out, 401, "VITHI EN / FRIENDLY EN TABLE");
                float x = 37, width = W - 74, top = 386, rowH = 17.0f;
                rect(out, x, top - 22, width, 22, NAVY, NAVY);
                label(out, BOLD, 9, x + 15, top - 15, Color.WHITE, "Vithi En");
                label(out, BOLD, 9, x + 184, top - 15, Color.WHITE, "Friendly En");
                label(out, BOLD, 8, x + 342, top - 15, Color.WHITE, "Selection");
                List<String> friendly = List.of("4", "7", "9", "1", "9", "9", "2", "5, 6", "");
                for (int n = 1; n <= 9; n++) {
                    float bottom = top - 22 - n * rowH;
                    boolean current = n == r.vithiEn();
                    rect(out, x, bottom, width, rowH, current ? GREEN : (n % 2 == 0 ? PALE : Color.WHITE), LINE);
                    if (current) rect(out, x, bottom, 4, rowH, GREEN_DARK, GREEN_DARK);
                    label(out, current ? BOLD : NORMAL, 9, x + 15, bottom + 4.8f, TEXT, Integer.toString(n));
                    label(out, current ? BOLD : NORMAL, 9, x + 184, bottom + 4.8f, TEXT, friendly.get(n - 1));
                    if (current) label(out, BOLD, 8, x + 342, bottom + 4.8f, GREEN_DARK, "SELECTED VITHI EN");
                }

                heading(out, 197, "NAKSHATRA PADA NAMING LETTERS - " + r.natchathiram());
                float pt = 183;
                rect(out, x, pt - 22, width, 22, NAVY, NAVY);
                label(out, BOLD, 9, x + 15, pt - 15, Color.WHITE, "Pada");
                label(out, BOLD, 9, x + 125, pt - 15, Color.WHITE, "English Naming Letters");
                label(out, BOLD, 9, x + 288, pt - 15, Color.WHITE, "Tamil");
                label(out, BOLD, 8, x + 410, pt - 15, Color.WHITE, "Selection");
                for (NakshatraPadaLetters.PadaLetter entry : r.padaLetters()) {
                    float bottom = pt - 22 - entry.pada() * 20;
                    boolean selected = entry.pada() == r.pada();
                    rect(out, x, bottom, width, 20, selected ? GREEN : (entry.pada() % 2 == 0 ? PALE : Color.WHITE), LINE);
                    if (selected) rect(out, x, bottom, 4, 20, GREEN_DARK, GREEN_DARK);
                    label(out, selected ? BOLD : NORMAL, 9.2f, x + 15, bottom + 6, TEXT, "Pada " + entry.pada());
                    label(out, selected ? BOLD : NORMAL, 9.2f, x + 125, bottom + 6, TEXT, entry.english());
                    drawTamil(out, document, "pada-" + slug(r.natchathiram()) + "-" + entry.pada() + ".png", x + 288, bottom + 3.5f, 14f);
                    if (selected) label(out, BOLD, 8, x + 410, bottom + 6, GREEN_DARK, "YOUR PADA");
                }
                label(out, NORMAL, 7.2f, 41, 74, MUTED, r.padaLettersUnverified()
                    ? "Mapping warning: supplied workbook marks this nakshatra's pada letters UNVERIFIED."
                    : "English naming-letter variants follow the supplied Nakshatra/Pada workbook.");
                label(out, NORMAL, 7.2f, 41, 62, MUTED, r.nearPadaBoundary()
                    ? "Boundary warning: verify the recorded time and pada using a high-precision Lahiri ephemeris."
                    : "Method: approximate geocentric lunar calculation with Lahiri ayanamsa.");
                line(out, 37, 50, W - 37, 50, LINE);
                label(out, NORMAL, 8, 41, 36, MUTED, "Generated by IK's Numerology  |  iksnumerology@gmail.com");
                label(out, NORMAL, 7.5f, 41, 24, MUTED, "Traditional interpretation; not a replacement for an independently verified ephemeris.");
            }
            document.save(bytes);
            return bytes.toByteArray();
        }
    }

    /** Packaged raster labels keep Tamil shaping accurate without shipping or depending on font files. */
    private static void drawTamil(PDPageContentStream out, PDDocument document,
                                  String fileName, float x, float y, float displayHeight) throws IOException {
        String path = "/pdf/tamil/" + fileName;
        try (InputStream resource = RaasiPdfService.class.getResourceAsStream(path)) {
            if (resource == null) throw new IOException("Missing packaged Tamil label: " + path);
            PDImageXObject label = PDImageXObject.createFromByteArray(document, resource.readAllBytes(), fileName);
            float displayWidth = displayHeight * label.getWidth() / label.getHeight();
            out.drawImage(label, x, y, displayWidth, displayHeight);
        }
    }

    private static String slug(String text) {
        return text.toLowerCase(Locale.ROOT).replaceAll("[^a-z]", "");
    }

    private static void field(PDPageContentStream out, float x, float y, String heading, String value) throws IOException {
        label(out, NORMAL, 8, x, y + 9, MUTED, heading);
        label(out, BOLD, 11, x, y - 5, TEXT, fit(value, BOLD, 11, 233));
    }

    private static void stat(PDPageContentStream out, float x, float y, float w, float h,
                             String title, String value, String sub) throws IOException {
        rect(out, x, y, w, h, PALE, LINE);
        label(out, BOLD, 8.3f, x + 13, y + h - 17, MUTED, title);
        label(out, BOLD, 17, x + 13, y + h - 40, NAVY, fit(value, BOLD, 17, w - 26));
        label(out, NORMAL, 8.5f, x + 13, y + 13, MUTED, fit(sub, NORMAL, 8.5f, w - 26));
    }

    private static void heading(PDPageContentStream out, float y, String text) throws IOException {
        label(out, BOLD, 10.2f, 39, y, NAVY, text);
    }

    private static void line(PDPageContentStream out, float x1, float y1, float x2, float y2, Color c) throws IOException {
        out.setStrokingColor(c);
        out.setLineWidth(0.7f);
        out.moveTo(x1, y1);
        out.lineTo(x2, y2);
        out.stroke();
    }

    private static void rect(PDPageContentStream out, float x, float y, float width, float height, Color fill, Color border) throws IOException {
        out.setNonStrokingColor(fill);
        out.addRect(x, y, width, height);
        out.fill();
        out.setStrokingColor(border);
        out.setLineWidth(0.6f);
        out.addRect(x, y, width, height);
        out.stroke();
    }

    private static void label(PDPageContentStream out, PDFont font, float fontSize, float x, float y,
                              Color color, String text) throws IOException {
        out.beginText();
        out.setFont(font, fontSize);
        out.setNonStrokingColor(color);
        out.newLineAtOffset(x, y);
        out.showText(pdfSafe(text));
        out.endText();
    }

    private static String fit(String value, PDFont font, float size, float maxWidth) throws IOException {
        String safe = pdfSafe(value);
        if (font.getStringWidth(safe) / 1000f * size <= maxWidth) return safe;
        while (!safe.isEmpty() && font.getStringWidth(safe + "...") / 1000f * size > maxWidth) {
            safe = safe.substring(0, safe.length() - 1);
        }
        return safe + "...";
    }

    // Standard 14 PDF fonts cover printable Latin characters; Tamil text is
    // rendered through packaged, correctly shaped transparent images above.
    private static String pdfSafe(String s) {
        if (s == null) return "";
        StringBuilder b = new StringBuilder();
        for (int i = 0; i < s.length(); i++) {
            char c = s.charAt(i);
            if (c == '\u2192') b.append(" -> ");
            else if (c == '\u2013' || c == '\u2014') b.append('-');
            else if (c >= 32 && c <= 126) b.append(c);
            else b.append('?');
        }
        return b.toString();
    }
}
